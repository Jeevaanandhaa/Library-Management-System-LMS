package books;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
@WebServlet("/ViewBookServlet")
public class ViewBooksServlet extends HttpServlet{  
public void doPost(HttpServletRequest req,HttpServletResponse res)  
throws ServletException,IOException  
{  
res.setContentType("text/html");  
PrintWriter pw=res.getWriter();  
String title=req.getParameter("title");  
String author=req.getParameter("author"); 

try{  
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection(  
	"jdbc:mysql://localhost:3306/Library","root","1NH20CV405#j");  
	//here sonoo is database name, root is username and password  
	PreparedStatement stmt=con.prepareStatement("select * from books where title=? and author=?");
	stmt.setString(1,title);
	stmt.setString(2,author);
	
	ResultSet rs=stmt.executeQuery();  
	while(rs.next()){  
		pw.print("<h1>"+"<center>"+"<br>"+"<br>"+"<br>"+"<br>"+"title:"+rs.getString(1)+"<br>"+" "+"author:"+rs.getString(2)+"<br>"+" "+"isbn:"+rs.getInt(3)+"<br>"+" "+"qualtity"+" "+rs.getInt(4)+"</center>"+"</h1>");  
	}  
	 
	  
	con.close();  
	  
	}catch(Exception e){ System.out.println(e);}  
	   
 
pw.close();  
}}
