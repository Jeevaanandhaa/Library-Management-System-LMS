package books;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;  

	@WebServlet("/AddUserServlet")
		
		
		public class AddUserServlet extends HttpServlet{  
		public void doGet(HttpServletRequest req,HttpServletResponse res)  
		throws ServletException,IOException  
		{  
		res.setContentType("text/html");
		
		
		PrintWriter pw=res.getWriter(); 
		int id = Integer.parseInt(req.getParameter("id"));
		  String name = req.getParameter("name");
	        String email = req.getParameter("email");

		
try{  
	Class.forName("com.mysql.jdbc.Driver");  

	Connection con=DriverManager.getConnection(  
	"jdbc:mysql://localhost:3306/Library","root","1NH20CV405#j");  
	//here sonoo is database name, root is username and password  
	PreparedStatement stmt=con.prepareStatement("insert into user values (?,?,?)");
	stmt.setInt(1, id);
	  stmt.setString(2, name);
	  stmt.setString(3, email);
	 
int i=stmt.executeUpdate();
System.out.println(i+"records inserted");

if(i!=0)
{
	System.out.println("NEW USER INSERTED");
}
else
{
	System.out.println(" NOT INSERTED");
}

con.close();  
}catch(Exception e){ System.out.println(e);} 
	pw.close();  
		}

	}


