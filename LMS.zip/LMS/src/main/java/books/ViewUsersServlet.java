package books;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 
@WebServlet("/ViewUserServlet")
public class ViewUsersServlet extends HttpServlet{  
public void doGet(HttpServletRequest req,HttpServletResponse res)  
throws ServletException,IOException  
{  
res.setContentType("text/html");  
PrintWriter pw=res.getWriter();


int id = Integer.parseInt(req.getParameter("id"));


 


try{  
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection(  
	"jdbc:mysql://localhost:3306/Library","root","1NH20CV405#j");  
	//here sonoo is database name, root is username and password  
	PreparedStatement stmt=con.prepareStatement("select * from user where id=?");
	stmt.setInt(1,id);

	
	ResultSet rs=stmt.executeQuery();  
	while(rs.next()){  
		pw.print("<h1>"+"<center>"+"<br>"+"<br>"+"<br>"+"<br>"+"id:"+rs.getInt(1)+"<br>"+" "+"name:"+rs.getString(2)+"<br>"+" "+"email:"+rs.getString(3)+"<br>"+"</center>"+"</h1>"); 
	} 
	
	
	
	  
	con.close();  
	  
	}catch(Exception e){ System.out.println(e);}  
	   
 
pw.close();  
}}
